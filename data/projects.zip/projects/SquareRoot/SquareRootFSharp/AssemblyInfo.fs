﻿namespace SquareRootFSharp.AssemblyInfo

open System.Reflection
open System.Runtime.CompilerServices
open System.Runtime.InteropServices

// Общие сведения о сборке можно задать с помощью следующего 
// набора атрибутов. Отредактируйте эти значения атрибутов, чтобы изменить сведения,
// связанные с этой сборкой.
[<assembly: AssemblyTitle("SquareRootFSharp")>]
[<assembly: AssemblyDescription("")>]
[<assembly: AssemblyConfiguration("")>]
[<assembly: AssemblyCompany("")>]
[<assembly: AssemblyProduct("SquareRootFSharp")>]
[<assembly: AssemblyCopyright("Copyright ©  2017")>]
[<assembly: AssemblyTrademark("")>]
[<assembly: AssemblyCulture("")>]

// При установке значения False в атрибуте ComVisible типы в этой сборке становятся невидимыми 
// для COM-компонентов.  Если требуется обратиться к типу в этой сборке через 
// COM, задайте для атрибута ComVisible значение True для этого типа.
[<assembly: ComVisible(false)>]

// Следующий GUID служит для идентификации библиотеки типов, если этот проект видим для COM
[<assembly: Guid("5ab9a124-ff8b-4255-adce-a567179c9a72")>]

// Сведения о версии сборки состоят из следующих четырех значений:
// 
//       Основной номер версии
//       Дополнительный номер версии 
//       Номер сборки
//      Редакция
// 
// Можно задать все значения или принять номера сборки и редакции по умолчанию 
// используя "*", как показано ниже:
// [<сборка: AssemblyVersion("1.0.*")>]
[<assembly: AssemblyVersion("1.0.0.0")>]
[<assembly: AssemblyFileVersion("1.0.0.0")>]

do
    ()