
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 08/17/2013 00:18:04
-- Generated from EDMX file: D:\root\yura\institute\!!!_asp_net_mvc\mvc\computers_03_12\Computers_03_12_2012\Computers\Models\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Computers_03_12_2012];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ProcessorComputer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ComputerSet] DROP CONSTRAINT [FK_ProcessorComputer];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[ProcessorSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProcessorSet];
GO
IF OBJECT_ID(N'[dbo].[ComputerSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ComputerSet];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'ProcessorSet'
CREATE TABLE [dbo].[ProcessorSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [ProcessorName] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'ComputerSet'
CREATE TABLE [dbo].[ComputerSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [ComputerName] nvarchar(max)  NOT NULL,
    [HDD] int  NOT NULL,
    [ProductionDate] datetime  NOT NULL,
    [Processor_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'ProcessorSet'
ALTER TABLE [dbo].[ProcessorSet]
ADD CONSTRAINT [PK_ProcessorSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ComputerSet'
ALTER TABLE [dbo].[ComputerSet]
ADD CONSTRAINT [PK_ComputerSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Processor_Id] in table 'ComputerSet'
ALTER TABLE [dbo].[ComputerSet]
ADD CONSTRAINT [FK_ProcessorComputer]
    FOREIGN KEY ([Processor_Id])
    REFERENCES [dbo].[ProcessorSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ProcessorComputer'
CREATE INDEX [IX_FK_ProcessorComputer]
ON [dbo].[ComputerSet]
    ([Processor_Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------