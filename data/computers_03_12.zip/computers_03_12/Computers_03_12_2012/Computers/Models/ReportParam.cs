﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Computers.Models
{
    public class ReportParam
    {
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Необходимо ввести начальную дату")]
        [DataType(DataType.Date)]
        public DateTime? BeginDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Необходимо ввести конечную дату")]
        [DataType(DataType.Date)]
        public DateTime? EndDate { get; set; }

    }
}