﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Computers.Models
{
    [MetadataType(typeof(ProcessorValidation))]
    public partial class Processor
    {
    }

    public class ProcessorValidation
    {
        [Required(ErrorMessage = "Необходимо ввести название процессора")]
        [StringLength(50, 
            ErrorMessage = "Длина строки не более 50 символов")]
        [RegularExpression("[A-Za-z0-9 ]*", 
            ErrorMessage = "Только символы латиницы и цифры")]
        public object ProcessorName { get; set; }
    }
}