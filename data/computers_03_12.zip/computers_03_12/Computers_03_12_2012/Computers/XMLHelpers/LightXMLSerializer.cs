﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.IO;

namespace Computers.XMLHelpers
{
    /// <summary>
    /// Сериализация XML
    /// </summary>
    public class LightXMLSerializer
    {
        /// <summary>
        /// Формат даты соответствующий стандарту XML
        /// </summary>
        public const string DateFormat = "yyyy-MM-ddTHH:mm:ss";
        
        protected StringBuilder Result;

        protected string IndentStr = "\t";

        /// <summary>
        /// Конструктор
        /// </summary>
        public LightXMLSerializer()
        {
            Result = new StringBuilder();
            Result.AppendLine("<?xml version='1.0' encoding='utf-8'?>");
        }

        /// <summary>
        /// Открытие элемента
        /// </summary>
        public void Open(string elementName)
        {
            Result.AppendLine("<" + elementName + ">");
        }

        /// <summary>
        /// Открытие элемента с отступом
        /// </summary>
        public void Open(int indent, string elementName)
        {
            AddIndent(indent);
            Result.AppendLine("<" + elementName + ">");
        }

        /// <summary>
        /// Открытие элемента с отступом с атрибутами
        /// </summary>
        public void Open(int indent, string elementName, Dictionary<string, string> attrs)
        {
            AddIndent(indent);
            Result.Append("<" + elementName);
            foreach (var attr in attrs)
            {
                Result.Append(" " + attr.Key + "='" + attr.Value + "' ");
            }
            Result.AppendLine(">");
        }

        /// <summary>
        /// Закрытие элемента
        /// </summary>
        public void Close(string elementName)
        {
            Result.AppendLine("</" + elementName + ">");
        }

        /// <summary>
        /// Закрытие элемента с отступом
        /// </summary>
        public void Close(int indent, string elementName)
        {
            AddIndent(indent);
            Result.AppendLine("</" + elementName + ">");
        }

        public void SimpleContent(string elementName, string elementValue)
        {
            Result.AppendLine("<" + elementName + ">" + elementValue + "</" + elementName + ">");
        }

        public void SimpleContent(int indent, string elementName, string elementValue)
        {
            AddIndent(indent);
            SimpleContent(elementName, elementValue);
        }

        public void AddIndent(int indent)
        {
            if (indent > 0) for (int i = 0; i < indent; i++) Result.Append(IndentStr);
        }

        /// <summary>
        /// Возврат результатата в виде строки
        /// </summary>
        public string XMLAsString
        {
            get
            {
                return Result.ToString();
            }
        }

        /// <summary>
        /// Сохранение результатов в файл
        /// </summary>
        public string WriteToFile(string path, string filename)
        {
            string sl = @"\";
            string fn = path.Trim();
            if (!fn.EndsWith(sl)) fn = fn + sl;
            fn = fn + filename + ".xml";

            //Удаление файла, если он существует
            if (File.Exists(fn))
            {
                File.Delete(fn);
            }

            //Запись данных в файл
            File.AppendAllText(fn, this.XMLAsString);
            return fn;
        }
    }

}