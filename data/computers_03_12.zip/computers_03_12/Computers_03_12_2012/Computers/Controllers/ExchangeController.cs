﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Computers.Models;
using System.Runtime.Serialization;
using System.IO;
using System.Xml;
using System.Text;
using System.Xml.Serialization;
using Computers.XMLHelpers;
using System.Web.Helpers;
using System.Xml.Linq;
using System.Diagnostics;

namespace Computers.Controllers
{
    //[Authorize(Roles = "admins")]
    public class ExchangeController : Controller
    {
        //
        // GET: /Exchange/

        private Model1Container db = new Model1Container();            

        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Выгрузка XML в стандартном варианте
        /// </summary>
        /// <returns></returns>
        public string LoadXML()
        {
            StringBuilder sb = new StringBuilder();

            using (XmlWriter writer = XmlWriter.Create(sb))
            {
                //Сериализация Entity Framework
                //DataContractSerializer serializer = new DataContractSerializer(db.ComputerSet.First().GetType());
                //serializer.WriteObject(writer, db.ComputerSet.First());

                //Стандартная сериализация XML
                XmlSerializer serializer = new XmlSerializer(db.ComputerSet.Include("Processor").First().GetType());
                serializer.Serialize(writer, db.ComputerSet.Include("Processor").First());
            }

            Response.ContentType = "text/xml";
            return sb.ToString();
        }


        public ActionResult LoadJson()
        {
            /*
            //Computers - аналог корневого элемента 
            var Result = new { Computers = 
                         from x in db.ComputerSet
                         select new
                         {
                            ComputerName = x.ComputerName,
                            HDD = x.HDD,
                            ProductionDate = x.ProductionDate,
                            Processor = x.Processor.ProcessorName
                         }};
             */

            var Result = from x in db.ComputerSet
                        select new
                        {
                            ComputerName = x.ComputerName,
                            HDD = x.HDD,
                            ProductionDate = x.ProductionDate,
                            Processor = x.Processor.ProcessorName
                        };

            return Json(Result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Формирование XML с использованием собственного класса сериализации
        /// </summary>
        /// <returns></returns>
        public string LoadXMLCustom()
        {
            string Result = MakeCustomXML();
            Response.ContentType = "text/xml";
            return Result;
        }

        /// <summary>
        /// Формирование XML для записи в файл
        /// </summary>
        /// <returns></returns>
        private string MakeCustomXML()
        {
            //Собственный класс сериализации
            LightXMLSerializer xml = new LightXMLSerializer();
            //Открывающий корневой тэг
            xml.Open("Computers");

            //Запись данных о каждом компьютере
            foreach (var x in db.ComputerSet)
            {
                Dictionary<string, string> attrs = new Dictionary<string, string>();
                attrs.Add("Id", x.Id.ToString());

                xml.Open(1, "Computer", attrs);

                xml.SimpleContent(2, "ComputerName", x.ComputerName);
                xml.SimpleContent(2, "HDD", x.HDD.ToString());
                xml.SimpleContent(2, "ProductionDate", x.ProductionDate.ToString(LightXMLSerializer.DateFormat));
                xml.SimpleContent(2, "ProcessorName", x.Processor.ProcessorName);
                xml.Close(1, "Computer");
            }

            //Закрывающий корневой тэг
            xml.Close("Computers");

            return xml.XMLAsString;
        }

        /// <summary>
        /// Загрузка данных
        /// </summary>
        /// <returns></returns>
        public ActionResult BeginUpload()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadResult(HttpPostedFileBase fileUpload, string clearDB)
        {
            bool Result = true;
            string ErrorMessage = "";
            int ComputerCount = 0;
            int ProcessorCount = 0;
            XElement data;

            //Чтение данных из HTTP-запроса
            try
            {
                data = XElement.Load(fileUpload.InputStream);
            }
            catch (Exception e)
            {
                Result = false;
                ErrorMessage = "Файл не является правильно сформированным файлом XML";
                ViewBag.ExceptionMessage = e.Message;
                goto ReturnView;
            }

            //Предварительное удаление данных из БД
            bool PrevDelete = (clearDB != null);
            if (PrevDelete)
            {
                db.ComputerSet.ToList().ForEach(db.ComputerSet.DeleteObject);
                db.ProcessorSet.ToList().ForEach(db.ProcessorSet.DeleteObject);
                db.SaveChanges();
            }

            //Загрузка данных в БД
            Stopwatch LoadTime = new Stopwatch();
            try
            {
                //Включение подсчета времени
                LoadTime.Start();

                //Выборка всех наименований процессоров
                var processors = (from x in data.Elements("Computer")
                                 group x by x.Element("ProcessorName").Value into grp
                                 select grp.Key).ToList();
              
                //Добавление процессоров в БД
                foreach (var x in processors)
                {
                    Processor temp = new Processor()
                    {
                         ProcessorName = x
                    };
                    //Добавление процессора
                    db.ProcessorSet.AddObject(temp);
                    //Увеличение счетчика
                    ProcessorCount++;
                }
                //Сохранение в БД
                db.SaveChanges();

                //Добавление компьютеров в БД
                var computers = from x in data.Elements("Computer") 
                                select x;

                foreach (var x in computers)
                {
                    //Поиск нужного процессора
                    string procName = x.Element("ProcessorName").Value.Trim().ToUpper();
                    var proc = db.ProcessorSet.First(p => p.ProcessorName.Trim().ToUpper() == procName);

                    Computer temp = new Computer()
                    {
                        Processor = proc,
                        ComputerName = x.Element("ComputerName").Value,
                        HDD = int.Parse(x.Element("HDD").Value),
                        ProductionDate = DateTime.ParseExact(x.Element("ProductionDate").Value, LightXMLSerializer.DateFormat, null)
                    };
                    //Добавление процессора
                    db.ComputerSet.AddObject(temp);
                    //Увеличение счетчика
                    ComputerCount++;
                }
                //Сохранение в БД
                db.SaveChanges();

                //Завершение подсчета времени                
                LoadTime.Stop();
                ViewBag.LoadTime = LoadTime.Elapsed.ToString();
            }
            catch (Exception e)
            {
                Result = false;
                ErrorMessage = "Не удалось загрузить данные в БД";
                ViewBag.ExceptionMessage = e.Message;
                goto ReturnView;
            }

        ReturnView:
            ViewBag.Result = Result;
            ViewBag.ErrorMessage = ErrorMessage;
            ViewBag.ComputerCount = ComputerCount;
            ViewBag.ProcessorCount = ProcessorCount;
            return View();
        }
    }
}
