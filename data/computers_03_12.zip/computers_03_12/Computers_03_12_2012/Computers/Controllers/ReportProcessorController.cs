﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Computers.Models;

namespace Computers.Controllers
{
    //[Authorize(Roles = "admins, report_persons")]
    public class ReportProcessorController : Controller
    {

        public ActionResult AskParams()
        {
            return View();
        } 

        [HttpPost]
        public ActionResult CreateReport(FormCollection collection)
        {
            string ErrorDate = "Необходимо указать дату в формате дд.мм.гггг";
            string ErrorInterval = "Начальная дата должна быть меньше или равна конечной";

            try
            {
                //Получение дат как строковых параметров
                string BeginDateStr = collection["BeginDate"];
                string EndDateStr = collection["EndDate"];
                
                //Преобразование в дату

                DateTime BeginDate;
                DateTime EndDate;
                bool ErrorFlag = false;

                if (!DateTime.TryParse(BeginDateStr, out BeginDate))
                {
                    ModelState.AddModelError("BeginDate", ErrorDate);
                    ErrorFlag = true;
                }

                if (!DateTime.TryParse(EndDateStr, out EndDate))
                {
                    ModelState.AddModelError("EndDate", ErrorDate);
                    ErrorFlag = true;
                }

                if (ErrorFlag)
                {
                    DateTime emptyDate = new DateTime(1,1,1);
                    ReportParam param = new ReportParam();
                    if (BeginDate != emptyDate) param.BeginDate = BeginDate;
                    if (EndDate != emptyDate) param.EndDate = EndDate;
                    return View("AskParams", param);
                }

                //Проверка того, что конечная дата не менее начальной
                if (EndDate < BeginDate)
                {
                    ReportParam param = new ReportParam()
                    {
                         BeginDate = BeginDate,
                         EndDate = EndDate
                    };

                    ModelState.AddModelError("", ErrorInterval);
                    return View("AskParams", param);
                }

                //Передача данных
                ViewBag.BeginDate = BeginDate;
                ViewBag.EndDate = EndDate;

                return View("Report");
            }
            catch
            {
                return View("AskParams");
            }
        }
        
    }
}
