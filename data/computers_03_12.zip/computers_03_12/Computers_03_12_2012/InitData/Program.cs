﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Computers.Models;

namespace InitData
{
    class Program
    {
        static void Main(string[] args)
        {
            RunInitData();
        }

        static void RunInitData()
        {
            Model1Container db = new Model1Container();

            //Удаление всех записей из таблицы "Процессоры"
            //foreach (var x in db.ProcessorSet)
            //{
            //    db.ProcessorSet.DeleteObject(x);
            //}

            db.ComputerSet.ToList().ForEach(db.ComputerSet.DeleteObject);
            db.ProcessorSet.ToList().ForEach(db.ProcessorSet.DeleteObject);

            Processor proc1 = new Processor
            {
                 ProcessorName = "Core 2 Duo"
            };

            Processor proc2 = new Processor
            {
                ProcessorName = "Core i3"
            };

            Processor proc3 = new Processor
            {
                ProcessorName = "Core i5"
            };

            Processor proc4 = new Processor
            {
                ProcessorName = "Core i7"
            };

            db.ProcessorSet.AddObject(proc1);
            db.ProcessorSet.AddObject(proc2);
            db.ProcessorSet.AddObject(proc3);
            db.ProcessorSet.AddObject(proc4);
            db.SaveChanges();


            for (int i = 0; i < 100; i++)
            {
                Processor temp = new Processor
                {
                     ProcessorName = "Processor_" + i.ToString()
                };
                db.ProcessorSet.AddObject(temp);
            }
            db.SaveChanges();


            Computer comp0_1 = new Computer
            {
                ComputerName = "Очень новый компьютер 1",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 23),
                Processor = proc4
            };

            Computer comp0_2 = new Computer
            {
                ComputerName = "Очень новый компьютер 2",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 23),
                Processor = proc4
            };

            Computer comp1 = new Computer
            {
                ComputerName = "Новый компьютер",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 23),
                Processor = proc3
            };

            Computer comp2 = new Computer
            {
                ComputerName = "Новый компьютер 2",
                HDD = 1000,
                ProductionDate = new DateTime(2012, 11, 25),
                Processor = proc3
            };

            Computer comp2_1 = new Computer
            {
                ComputerName = "Новый компьютер 3",
                HDD = 1000,
                ProductionDate = new DateTime(2012, 11, 25),
                Processor = proc3
            };

            Computer comp3 = new Computer
            {
                ComputerName = "Не очень новый компьютер 1",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 10),
                Processor = proc2
            };

            Computer comp3_1 = new Computer
            {
                ComputerName = "Не очень новый компьютер 2",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 10),
                Processor = proc2
            };

            Computer comp4 = new Computer
            {
                ComputerName = "Старый компьютер",
                HDD = 500,
                ProductionDate = new DateTime(2012, 11, 5),
                Processor = proc1
            };

            db.ComputerSet.AddObject(comp0_1);
            db.ComputerSet.AddObject(comp0_2);
            db.ComputerSet.AddObject(comp1);
            db.ComputerSet.AddObject(comp2);
            db.ComputerSet.AddObject(comp2_1);
            db.ComputerSet.AddObject(comp3);
            db.ComputerSet.AddObject(comp3_1);
            db.ComputerSet.AddObject(comp4);
            db.SaveChanges();

            /*
            foreach (var x in db.ProcessorSet)
            {
                Console.WriteLine(x.ProcessorName);
                foreach (var c in x.Computer)
                {
                    Console.WriteLine("   " + c.ComputerName);
                }
            }
            Console.ReadLine();
            */
        }
    }
}
