﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sharp_intro
{
    class Program
    {
        static int Sum(int a, int b)
        {
            int result = a + b;
            return result;
        }

        static void Main(string[] args)
        {
            /*
            int a = 1;
            int b = 2;
            int c = Sum(a, b);

            Console.WriteLine(c);
            */

            /*
            int i;
            string iStr = Console.ReadLine();

            //bool flag = int.TryParse(iStr, out i);

            if (int.TryParse(iStr, out i))
            {
                Console.WriteLine(i);
            }
            else
            {
                Console.WriteLine("Не число");
            }
             * 
             * 
             */
 

            double a; 
            double b;
            double c;
            double d;
            int rootCount;
            double root1;
            double root2;

            while(!Square.GetDouble("Введите А:", "Коэффициент А введен неправильно", out a));
            while (!Square.GetDouble("Введите B:", "Коэффициент B введен неправильно", out b)) ;
            while (!Square.GetDouble("Введите C:", "Коэффициент C введен неправильно", out c)) ;

            Square.Solve(a, b, c, out d, out rootCount, out root1, out root2);

            if (rootCount == 2)
            {
                Console.WriteLine("Корни {0} и {1}", 
                    root1, root2);
            }
            else if (rootCount == 1)
            {
                Console.WriteLine("Корень {0}",
                    root1);
            }
            else
            {
                Console.WriteLine("Корней нет");
            }


            Console.ReadLine();
        }
    }
}
