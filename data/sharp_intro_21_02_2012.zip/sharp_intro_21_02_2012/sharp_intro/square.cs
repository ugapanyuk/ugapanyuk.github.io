﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sharp_intro
{
    class Square
    {

        public static bool GetDouble(
            string mes,
            string mesError,
            out double Result)
        {
            Console.Write(mes);
            string strDouble = Console.ReadLine();
            bool flag = double.TryParse(strDouble, out Result);

            if (!flag)
            {
                Console.WriteLine(mesError);
            }

            return flag;
        }

        /// <summary>
        /// Решение квадратного уравнения
        /// </summary>
        /// <param name="a">Коэффициент А</param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <param name="d"></param>
        /// <param name="rootCount"></param>
        /// <param name="root1"></param>
        /// <param name="root2"></param>
        public static void Solve(
            double a, //Коэффициенты 
            double b,
            double c,
            out double d,
            out int rootCount,
            out double root1,
            out double root2
            )
        {
            //Вычисление дискриминанта
            d = b * b - 4 * a * c;

            //Определение корней
            if (d < 0)
            {
                rootCount = 0;
                root1 = 0;
                root2 = 0;
            }
            else if (d == 0)
            {
                rootCount = 1;
                root1 = -b / (2 * a);
                root2 = root1;
            }
            else
            {
                rootCount = 2;
                root1 = (-b - Math.Sqrt(d)) / (2 * a);
                root2 = (-b + Math.Sqrt(d)) / (2 * a);
            }

        }




    }
}
