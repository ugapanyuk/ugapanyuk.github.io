﻿{
    values:
    [
                    {
                        v: "value1",
                        t: "строка1"
                    },
                    {
                        v: "value2",
                        t: "строка2"
                    },
                    {
                        v: "value3",
                        t: "строка3"
                    },
                ]

}