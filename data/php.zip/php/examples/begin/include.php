<html>
<head>
  <title>��������� PHP</title>
</head>
<body>
<?php 

require ('req1.php');
include ('inc1.php');

echo("<H1>" . $StrReq . "</H1>");
echo("<H1>" . $StrInc . "</H1>");

?>
</body>
</html> 