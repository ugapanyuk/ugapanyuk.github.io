<?php 
	  $res = `dir c:`;	
	  echo("<PRE>" . $res . "</PRE>"); 
?>
