﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Computers.Models;
using PagedList;
using PagedList.Mvc;
using System.Data.Objects;

namespace Computers.Controllers
{
    [Authorize(Roles = "admins, data_persons")]
    public class ProcessorController : Controller
    {
        const int PageSize = 5;

        private Model1Container db = new Model1Container();

        //
        // GET: /Processor/

        public ViewResult Index(int? page, string filter = "", string order = "")
        {
            IEnumerable<Processor> data = db.ProcessorSet; 
            //returns IQueryable<Product> representing an unknown number 
            //of products. a thousand maybe?

            var pageNumber = page ?? 1; // if no page was specified in the querystring, default to the first page (1)

            //Установка фильтра если он непустой
            if (!string.IsNullOrWhiteSpace(filter))
            {
                string upperFilter = filter.Trim().ToUpper();
                data = data.Where(x => x.ProcessorName.ToUpper().Contains(upperFilter));
                ViewBag.Filter = filter.Trim();
            }

            //Сортировка данных
            if (order == "ProcessorName_Asc")
            {
                data = data.OrderBy(x => x.ProcessorName);
            }
            else if (order == "ProcessorName_Desc")
            {
                data = data.OrderByDescending(x => x.ProcessorName);
            }
            else
            {
                data = data.OrderBy(x => x.ProcessorName);
            }

            //Сохранение данных о текущей сортировке, чтобы она не терялясь при изменении фильтра
            ViewBag.Order = order;

            //Получение одной страницы данных
            var onePageOfData = data.ToPagedList(pageNumber, PageSize); 

            ViewBag.OnePageOfData = onePageOfData;

            return View();
            
            /////////////////////////////////////
            //return View(db.ProcessorSet.ToList());
        }

        /// <summary>
        /// Фильтр и сортировка
        /// </summary>
        [HttpPost]
        public ActionResult Index(string filter, string SetFilter, string ClearFilter, string order)
        {
            string ResultFilter = "";

            if (!string.IsNullOrWhiteSpace(SetFilter))
            {
                if (!string.IsNullOrWhiteSpace(filter))
                {
                    ResultFilter = filter.Trim();
                }
            }
            return RedirectToAction("Index", new { page = 1, filter = ResultFilter, order = order });
        }


        //
        // GET: /Processor/Details/5

        public ViewResult Details(int id)
        {
            Processor processor = db.ProcessorSet.Single(p => p.Id == id);
            return View(processor);
        }

        //
        // GET: /Processor/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Processor/Create

        [HttpPost]
        public ActionResult Create(Processor processor)
        {
            //Если процессор с таким названием существует, то формируется ошибка
            if (
                db.ProcessorSet.Any(x => x.ProcessorName.Trim().ToUpper().Equals(processor.ProcessorName.Trim().ToUpper()))
                )
            {
                ModelState.AddModelError("ProcessorName", "Процессор с таким названием уже существует");
            }

            if (ModelState.IsValid)
            {
                db.ProcessorSet.AddObject(processor);
                db.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(processor);
        }
        
        //
        // GET: /Processor/Edit/5
 
        public ActionResult Edit(int id)
        {
            Processor processor = db.ProcessorSet.Single(p => p.Id == id);
            return View(processor);
        }

        //
        // POST: /Processor/Edit/5

        [HttpPost]
        public ActionResult Edit(Processor processor)
        {
            //Если процессор с таким названием существует, то формируется ошибка
            if (
                db.ProcessorSet.Any(x => x.ProcessorName.Trim().ToUpper().Equals(processor.ProcessorName.Trim().ToUpper()))
                )
            {
                ModelState.AddModelError("ProcessorName", "Процессор с таким названием уже существует");
            }

            if (ModelState.IsValid)
            {
                db.ProcessorSet.Attach(processor);
                db.ObjectStateManager.ChangeObjectState(processor, EntityState.Modified);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(processor);
        }

        //
        // GET: /Processor/Delete/5
 
        public ActionResult Delete(int id)
        {
            Processor processor = db.ProcessorSet.Single(p => p.Id == id);
            return View(processor);
        }

        //
        // POST: /Processor/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            Processor processor = db.ProcessorSet.Single(p => p.Id == id);
            db.ProcessorSet.DeleteObject(processor);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}