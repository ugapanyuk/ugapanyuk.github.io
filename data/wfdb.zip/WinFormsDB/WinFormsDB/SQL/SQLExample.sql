USE [db1]
GO

IF  EXISTS (SELECT * FROM sys.objects 
WHERE object_id = OBJECT_ID(N'[dbo].[Table1]') AND type in (N'U'))
DROP TABLE [dbo].[Table1]

Create Table Table1(
	id int IDENTITY(1,1) NOT NULL,
	text1 nvarchar(MAX),
    number1 Int,
    date1 DateTime);

Select * From Table1;

Insert Into Table1(text1,number1,date1) 
Values ('text',333, '1/2/2006');

Select date1, text1 From Table1;

Insert Into Table1(text1,number1,date1) 
Values 
('string1',1,'1/2/2006'),
('string2',1,'1/2/2006'),
('string3',1,'1/2/2006');

Select * From Table1;

ALTER TABLE Table1 ADD number2 Real;

Select * From Table1;

Update Table1 Set number2 = 333.333;

Select * From Table1;

Update Table1 
Set 
text1='TextTextText', 
number2=334 
where number1=1;

Select * From Table1;


