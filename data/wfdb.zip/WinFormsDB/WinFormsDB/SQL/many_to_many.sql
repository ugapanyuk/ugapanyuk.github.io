USE [db1]
GO

-- �������� ������

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Sotr2_To_Dep2_Dep2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Sotr2_To_Dep2]'))
ALTER TABLE [dbo].[Sotr2_To_Dep2] DROP CONSTRAINT [FK_Sotr2_To_Dep2_Dep2]
GO

IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Sotr2_To_Dep2_Sotr2]') AND parent_object_id = OBJECT_ID(N'[dbo].[Sotr2_To_Dep2]'))
ALTER TABLE [dbo].[Sotr2_To_Dep2] DROP CONSTRAINT [FK_Sotr2_To_Dep2_Sotr2]
GO

USE [db1]
GO

--------------------------------------------------------

/****** Object:  Table [dbo].[Dep2]    Script Date: 05/09/2012 19:23:26 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Dep2]') AND type in (N'U'))
DROP TABLE [dbo].[Dep2]
GO

USE [db1]
GO

/****** Object:  Table [dbo].[Dep2]    Script Date: 05/09/2012 19:23:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Dep2](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[DepName] [nchar](100) NULL,
 CONSTRAINT [PK_Dep2] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

-------------------------------------------

USE [db1]
GO

/****** Object:  Table [dbo].[Sotr2]    Script Date: 05/09/2012 19:24:21 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Sotr2]') AND type in (N'U'))
DROP TABLE [dbo].[Sotr2]
GO

USE [db1]
GO

/****** Object:  Table [dbo].[Sotr2]    Script Date: 05/09/2012 19:24:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sotr2](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nchar](100) NULL,
 CONSTRAINT [PK_Sotr2] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

--------------------------------------------

USE [db1]
GO

/****** Object:  Table [dbo].[Sotr2_To_Dep2]    Script Date: 05/09/2012 19:24:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Sotr2_To_Dep2]') AND type in (N'U'))
DROP TABLE [dbo].[Sotr2_To_Dep2]
GO

USE [db1]
GO

/****** Object:  Table [dbo].[Sotr2_To_Dep2]    Script Date: 05/09/2012 19:24:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Sotr2_To_Dep2](
	[sotr_id] [int] NOT NULL,
	[dep_id] [int] NOT NULL,
 CONSTRAINT [PK_Sotr2_To_Dep2] PRIMARY KEY CLUSTERED 
(
	[sotr_id] ASC,
	[dep_id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Sotr2_To_Dep2]  WITH CHECK ADD  CONSTRAINT [FK_Sotr2_To_Dep2_Dep2] FOREIGN KEY([dep_id])
REFERENCES [dbo].[Dep2] ([id])
GO

ALTER TABLE [dbo].[Sotr2_To_Dep2] CHECK CONSTRAINT [FK_Sotr2_To_Dep2_Dep2]
GO

ALTER TABLE [dbo].[Sotr2_To_Dep2]  WITH CHECK ADD  CONSTRAINT [FK_Sotr2_To_Dep2_Sotr2] FOREIGN KEY([sotr_id])
REFERENCES [dbo].[Sotr2] ([id])
GO

ALTER TABLE [dbo].[Sotr2_To_Dep2] CHECK CONSTRAINT [FK_Sotr2_To_Dep2_Sotr2]
GO


-- ���������� �������

SET IDENTITY_INSERT [dbo].[Dep2] ON
GO


Insert Into Dep2(id, DepName) values
(1, '����������'),
(2, '�����������������'),
(3, '������ �����');


SET IDENTITY_INSERT [dbo].[Dep2] OFF
GO

SET IDENTITY_INSERT [dbo].[Sotr2] ON
GO


Insert Into Sotr2(id, Name) values
(1, '������'),
(2, '������'),
(3, '��������');

Insert Into Sotr2_To_Dep2(sotr_id, dep_id) values
(1,1),
(2,2),
(3,1),
(3,2);

-- ���������� ������

-- ���������� ����������
select * 
from (Sotr2 s inner join Sotr2_To_Dep2 sd on s.id = sd.sotr_id) 
inner join Dep2 d on sd.dep_id = d.id

-- ������� ����������
select * 
from (Sotr2 s inner join Sotr2_To_Dep2 sd on s.id = sd.sotr_id) 
right join Dep2 d on sd.dep_id = d.id

-- ���������� ����������� � ������ ������

Select d.DepName, COUNT(s.id) "���������� �����������"
from (Sotr2 s inner join Sotr2_To_Dep2 sd on s.id = sd.sotr_id) 
right join Dep2 d on sd.dep_id = d.id
Group By d.DepName
Order By d.DepName Desc
