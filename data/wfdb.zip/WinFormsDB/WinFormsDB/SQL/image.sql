﻿USE [db1]
GO

/****** Object:  Table [dbo].[ImageTable]    Script Date: 05/22/2012 03:14:27 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ImageTable]') AND type in (N'U'))
DROP TABLE [dbo].[ImageTable]
GO

USE [db1]
GO

/****** Object:  Table [dbo].[ImageTable]    Script Date: 05/22/2012 03:14:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ImageTable](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[image1] [image] NULL,
	[image2] [image] NULL,
 CONSTRAINT [PK_ImageTable] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO


