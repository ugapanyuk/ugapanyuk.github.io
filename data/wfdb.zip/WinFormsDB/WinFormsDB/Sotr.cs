﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinFormsDB
{
    public partial class Sotr : Form
    {
        public Sotr()
        {
            InitializeComponent();
        }

        private void Sotr_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'db1DataSet.Sotr' table. You can move, or remove it, as needed.
            this.sotrTableAdapter.Fill(this.db1DataSet.Sotr);
            // TODO: This line of code loads data into the 'db1DataSet.Dep' table. You can move, or remove it, as needed.
            this.depTableAdapter.Fill(this.db1DataSet.Dep);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
