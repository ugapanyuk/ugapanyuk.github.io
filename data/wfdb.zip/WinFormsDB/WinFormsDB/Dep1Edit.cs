﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinFormsDB
{
    public partial class Dep1Edit : Form
    {
        public Dep1Edit()
        {
            InitializeComponent();
        }

        private void Dep1Edit_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'db1DataSet1.Dep' table. You can move, or remove it, as needed.
            this.depTableAdapter.Fill(this.db1DataSet1.Dep);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //depTableAdapter.Fill(this.db1DataSet1.Dep);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            depBindingSource.EndEdit();
            depTableAdapter.Update(this.db1DataSet1.Dep);
        }
    }
}
