﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinFormsDB
{
    public partial class Dep1Form : Form
    {
        public Dep1Form()
        {
            InitializeComponent();
        }

        private void Dep1Form_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'db1DataSet.Dep' table. You can move, or remove it, as needed.
            this.depTableAdapter.Fill(this.db1DataSet.Dep);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            depTableAdapter.Update(db1DataSet.Dep);
            this.Close();
        }
    }
}
