﻿namespace WinFormsDB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.одинкомногимToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.многокомногимToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.отделыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отделыполеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникидваСпискаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиредактированиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изображенияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.одинкомногимToolStripMenuItem,
            this.многокомногимToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(386, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // одинкомногимToolStripMenuItem
            // 
            this.одинкомногимToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отделыToolStripMenuItem,
            this.отделыполеToolStripMenuItem,
            this.сотрудникидваСпискаToolStripMenuItem,
            this.сотрудникиредактированиеToolStripMenuItem});
            this.одинкомногимToolStripMenuItem.Name = "одинкомногимToolStripMenuItem";
            this.одинкомногимToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.одинкомногимToolStripMenuItem.Text = "Данные";
            // 
            // многокомногимToolStripMenuItem
            // 
            this.многокомногимToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.изображенияToolStripMenuItem});
            this.многокомногимToolStripMenuItem.Name = "многокомногимToolStripMenuItem";
            this.многокомногимToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.многокомногимToolStripMenuItem.Text = "Изображения";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem1});
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.выходToolStripMenuItem1_Click);
            // 
            // отделыToolStripMenuItem
            // 
            this.отделыToolStripMenuItem.Name = "отделыToolStripMenuItem";
            this.отделыToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.отделыToolStripMenuItem.Text = "Отделы";
            this.отделыToolStripMenuItem.Click += new System.EventHandler(this.отделыToolStripMenuItem_Click);
            // 
            // отделыполеToolStripMenuItem
            // 
            this.отделыполеToolStripMenuItem.Name = "отделыполеToolStripMenuItem";
            this.отделыполеToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.отделыполеToolStripMenuItem.Text = "Отделы (поле)";
            this.отделыполеToolStripMenuItem.Click += new System.EventHandler(this.отделыполеToolStripMenuItem_Click);
            // 
            // сотрудникидваСпискаToolStripMenuItem
            // 
            this.сотрудникидваСпискаToolStripMenuItem.Name = "сотрудникидваСпискаToolStripMenuItem";
            this.сотрудникидваСпискаToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.сотрудникидваСпискаToolStripMenuItem.Text = "Сотрудники (два списка)";
            this.сотрудникидваСпискаToolStripMenuItem.Click += new System.EventHandler(this.сотрудникидваСпискаToolStripMenuItem_Click);
            // 
            // сотрудникиредактированиеToolStripMenuItem
            // 
            this.сотрудникиредактированиеToolStripMenuItem.Name = "сотрудникиредактированиеToolStripMenuItem";
            this.сотрудникиредактированиеToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.сотрудникиредактированиеToolStripMenuItem.Text = "Сотрудники (редактирование)";
            this.сотрудникиредактированиеToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиредактированиеToolStripMenuItem_Click);
            // 
            // изображенияToolStripMenuItem
            // 
            this.изображенияToolStripMenuItem.Name = "изображенияToolStripMenuItem";
            this.изображенияToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.изображенияToolStripMenuItem.Text = "Изображения";
            this.изображенияToolStripMenuItem.Click += new System.EventHandler(this.изображенияToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 262);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Меню";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem одинкомногимToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem многокомногимToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem отделыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отделыполеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникидваСпискаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиредактированиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изображенияToolStripMenuItem;
    }
}

