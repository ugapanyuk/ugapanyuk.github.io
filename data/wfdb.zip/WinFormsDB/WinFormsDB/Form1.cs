﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinFormsDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Выход?","", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void отделыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new Dep1Form();
            form.ShowDialog();
        }

        private void отделыполеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new Dep1Edit();
            form.ShowDialog();
        }

        private void сотрудникидваСпискаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new Sotr();
            form.ShowDialog();
        }

        private void сотрудникиредактированиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new SotrEdit();
            form.ShowDialog();
        }

        private void изображенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new ImageForm();
            form.ShowDialog();
        }
    }
}
