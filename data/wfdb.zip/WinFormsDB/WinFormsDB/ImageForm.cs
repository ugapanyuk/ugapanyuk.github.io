﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WinFormsDB
{
    public partial class ImageForm : Form
    {
        public ImageForm()
        {
            InitializeComponent();
        }

        private void ImageForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'db1DataSet.ImageTable' table. You can move, or remove it, as needed.
            this.imageTableTableAdapter.Fill(this.db1DataSet.ImageTable);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = "";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Файлы изображений|*.bmp;*.jpg;*.gif;*.png";
            dlg.Multiselect = false;
            dlg.CheckFileExists = true;
            dlg.ShowDialog();

            if (dlg.FileName != "")
            {
                path = dlg.FileName;
                byte[] bytes = File.ReadAllBytes(path);
                this.imageTableTableAdapter.Insert(bytes, bytes);

                this.imageTableTableAdapter.Fill(this.db1DataSet.ImageTable);

            }
            else
            {
                MessageBox.Show("не выбран файл");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            draw(); 
        }

        private void draw()
        {
            Pen p1 = new Pen(Color.Green, 10);
            Graphics g = pictureBox2.CreateGraphics();

            g.DrawEllipse(p1, 10, 10, 50, 40);
        }



    }
}
